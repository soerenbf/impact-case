(function () {
    angular.module('app', [
        'ui.router',
        'ngMockE2E'
    ]);
})();
